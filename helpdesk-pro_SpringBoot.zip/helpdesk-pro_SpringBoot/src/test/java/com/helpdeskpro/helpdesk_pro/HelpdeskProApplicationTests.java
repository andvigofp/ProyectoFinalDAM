package com.helpdeskpro.helpdesk_pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpdeskProApplicationTests {

	@Test
	void contextLoads() {
	}

}
