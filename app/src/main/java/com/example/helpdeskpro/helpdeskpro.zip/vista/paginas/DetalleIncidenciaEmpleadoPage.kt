package com.example.helpdeskpro.vista.paginas

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.helpdeskpro.R
import com.example.helpdeskpro.viemodel.vm.DetalleIncidenciaEmpleadoViewModel
import com.example.helpdeskpro.vista.componentes.detalleIncidenciaEmpleadoComponente.CabeceraDetalleIncidenciaEmpleadoComponent
import com.example.helpdeskpro.vista.componentes.detalleIncidenciaEmpleadoComponente.ComentariosIncidenciaEmpleadoComponent
import com.example.helpdeskpro.vista.componentes.detalleIncidenciaEmpleadoComponente.HistorialIncidenciaEmpleadoComponent
import com.example.helpdeskpro.vista.componentes.homeEmpleadoComponete.HomeBottomBarComponent
import com.example.helpdeskpro.vista.componentes.homeEmpleadoComponete.HomeTab
import com.example.helpdeskpro.vista.componentes.toolbarComponenete.ToolbarDetalleIncidenciaComponent

@Composable
fun DetalleIncidenciaEmpleadoPage(
    viewModel: DetalleIncidenciaEmpleadoViewModel,
    modifier: Modifier = Modifier,
    onVolver: () -> Unit = {},
    onInicio: () -> Unit = {},
    onNueva: () -> Unit = {},
    onPerfil: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(viewModel.incidenciaId) {
        viewModel.cargarDetalle()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.surface,
        bottomBar = {
            HomeBottomBarComponent(
                selectedTab = HomeTab.INICIO,
                onInicio = onInicio,
                onNueva = onNueva,
                onPerfil = onPerfil
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 16.dp)
        ) {
            ToolbarDetalleIncidenciaComponent(onVolver = onVolver)
            Spacer(modifier = Modifier.height(22.dp))

            when {
                uiState.isLoading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                uiState.detalle == null -> {
                    Text(
                        text = uiState.errorMessage
                            ?: stringResource(R.string.no_incident_detail),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }

                else -> {
                    val detalle = uiState.detalle!!
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        CabeceraDetalleIncidenciaEmpleadoComponent(incidencia = detalle)

                        if (uiState.errorMessage != null) {
                            Text(
                                text = uiState.errorMessage.orEmpty(),
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        ComentariosIncidenciaEmpleadoComponent(
                            comentarios = detalle.comentarios,
                            comentario = uiState.comentario,
                            comentarioError = uiState.comentarioError,
                            isSending = uiState.isSending,
                            onComentarioChange = viewModel::onComentarioChange,
                            onEnviarComentario = viewModel::enviarComentario
                        )
                        HistorialIncidenciaEmpleadoComponent(historial = detalle.historial)
                    }
                }
            }
        }
    }
}
