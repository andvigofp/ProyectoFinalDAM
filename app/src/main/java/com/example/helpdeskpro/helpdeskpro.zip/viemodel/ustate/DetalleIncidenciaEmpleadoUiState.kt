package com.example.helpdeskpro.viemodel.ustate

import com.example.helpdeskpro.modelo.DetalleIncidenciaEmpleadoDTO

data class DetalleIncidenciaEmpleadoUiState(
    val detalle: DetalleIncidenciaEmpleadoDTO? = null,
    val comentario: String = "",
    val comentarioError: String? = null,
    val isLoading: Boolean = false,
    val isSending: Boolean = false,
    val errorMessage: String? = null
)
