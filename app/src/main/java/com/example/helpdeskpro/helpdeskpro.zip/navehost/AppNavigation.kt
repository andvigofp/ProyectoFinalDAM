package com.example.helpdeskpro.navehost

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.helpdeskpro.HelpdeskProApp
import com.example.helpdeskpro.R
import com.example.helpdeskpro.viemodel.vm.AdminUsuariosViewModel
import com.example.helpdeskpro.viemodel.vm.AdminUsuariosViewModelFactory
import com.example.helpdeskpro.viemodel.vm.CrearCuentaViewModel
import com.example.helpdeskpro.viemodel.vm.CrearCuentaViewModelFactory
import com.example.helpdeskpro.viemodel.vm.DetalleEmpleadoViewModel
import com.example.helpdeskpro.viemodel.vm.DetalleEmpleadoViewModelFactory
import com.example.helpdeskpro.viemodel.vm.DetalleIncidenciaEmpleadoViewModel
import com.example.helpdeskpro.viemodel.vm.DetalleIncidenciaEmpleadoViewModelFactory
import com.example.helpdeskpro.viemodel.vm.EditarPerfilViewModel
import com.example.helpdeskpro.viemodel.vm.EditarPerfilViewModelFactory
import com.example.helpdeskpro.viemodel.vm.HomeEmpleadoViewModel
import com.example.helpdeskpro.viemodel.vm.HomeEmpleadoViewModelFactory
import com.example.helpdeskpro.viemodel.vm.HomeAdminViewModel
import com.example.helpdeskpro.viemodel.vm.HomeAdminViewModelFactory
import com.example.helpdeskpro.viemodel.vm.HomeTecnicoViewModel
import com.example.helpdeskpro.viemodel.vm.HomeTecnicoViewModelFactory
import com.example.helpdeskpro.viemodel.vm.LoginViewModel
import com.example.helpdeskpro.viemodel.vm.LoginViewModelFactory
import com.example.helpdeskpro.viemodel.vm.NuevaIncidenciaViewModel
import com.example.helpdeskpro.viemodel.vm.NuevaIncidenciaViewModelFactory
import com.example.helpdeskpro.viemodel.vm.PerfilViewModel
import com.example.helpdeskpro.viemodel.vm.PerfilViewModelFactory
import com.example.helpdeskpro.viemodel.vm.RecuperarContrasenaViewModel
import com.example.helpdeskpro.viemodel.vm.RecuperarContrasenaViewModelFactory
import com.example.helpdeskpro.viemodel.vm.RestablecerContrasenaViewModel
import com.example.helpdeskpro.viemodel.vm.RestablecerContrasenaViewModelFactory
import com.example.helpdeskpro.vista.componentes.homeEmpleadoComponete.HomeTab
import com.example.helpdeskpro.vista.paginas.AdminCrearUsuarioCrearPage
import com.example.helpdeskpro.vista.paginas.AdminUsuariosPage
import com.example.helpdeskpro.vista.paginas.CrearCuentaPage
import com.example.helpdeskpro.vista.paginas.DetalleIncideciaTecnicoPage
import com.example.helpdeskpro.vista.paginas.DetalleIncidenciaEmpleadoPage
import com.example.helpdeskpro.vista.paginas.EditarPerfilPage
import com.example.helpdeskpro.vista.paginas.HomeEmpleadoPage
import com.example.helpdeskpro.vista.paginas.HomeAdminPage
import com.example.helpdeskpro.vista.paginas.HomeTecnicoPage
import com.example.helpdeskpro.vista.paginas.LoginPage
import com.example.helpdeskpro.vista.paginas.NuevaIncidenciaPage
import com.example.helpdeskpro.vista.paginas.PerfilPage
import com.example.helpdeskpro.vista.paginas.RecuperarContrasenaPage
import com.example.helpdeskpro.vista.paginas.RestablecerContrasenaPage
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Configura la navegación y conecta cada página con su ViewModel.
 *
 * @param modifier modificador aplicado al contenedor de navegación.
 */
@Composable
fun AppNavigation(modifier: Modifier = Modifier) {

    val navController = rememberNavController()
    val application = LocalContext.current.applicationContext as HelpdeskProApp
    val coroutineScope = rememberCoroutineScope()
    val authRepository = application.authRepository
    val incidenciasRepository = application.incidenciasRepository
    val perfilRepository = application.perfilRepository
    val administracionRepository = application.administracionRepository

    // ---------- CONTROL DE SESIÓN ----------
    LaunchedEffect(Unit) {
        SessionEvents.forbidden.collect {
            navController.navigate(RouteNavigation.Login) {
                popUpTo(navController.graph.id) {
                    inclusive = true
                }
                launchSingleTop = true
            }
        }
    }

// ---------- NAVEGACIÓN GLOBAL ----------
    LaunchedEffect(Unit) {
        SessionEvents.navigation.collectLatest { route ->
            when (route) {
                is RouteNavigation.Login,
                is RouteNavigation.CrearCuenta,
                is RouteNavigation.RecuperarContrasena,
                is RouteNavigation.RestablecerContrasena,
                is RouteNavigation.HomeEmpleado,
                is RouteNavigation.HomeTecnico,
                is RouteNavigation.HomeAdmin,
                is RouteNavigation.AdminIncidencias,
                is RouteNavigation.AdminUsuarios,
                is RouteNavigation.AdminUsuario,
                is RouteNavigation.NuevaIncidencia,
                is RouteNavigation.DetalleIncidenciaEmpleado,
                is RouteNavigation.DetalleIncidenciaTecnico,
                is RouteNavigation.Perfil,
                is RouteNavigation.EditarPerfil -> navController.navigate(route)
            }
        }
    }

    /**
     * Navega al destino indicado y evita duplicar el destino superior.
     *
     * @param route destino al que navegar.
     */
    fun navigate(route: RouteNavigation) {
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    /** Regresa al login o lo abre si no hay una pantalla anterior. */
    fun volverALogin() {
        if (!navController.popBackStack()) {
            navigate(RouteNavigation.Login)
        }
    }

    NavHost(
        navController = navController,
        startDestination = RouteNavigation.Login,
        modifier = modifier
    ) {

        // ---------- LOGIN ----------
        composable<RouteNavigation.Login> {

            val loginViewModel: LoginViewModel = viewModel(
                factory = LoginViewModelFactory(application, authRepository)
            )

            LoginPage(
                loginViewModel = loginViewModel,
                onLoginSuccess = { userId, rol ->
                    when (rol.uppercase()) {
                        "TECNICO" -> navigate(RouteNavigation.HomeTecnico(userId))
                        "ADMINISTRADOR" -> navigate(RouteNavigation.HomeAdmin(userId))
                        else -> navigate(RouteNavigation.HomeEmpleado(userId))
                    }
                },
                onForgotPassword = {
                    navigate(RouteNavigation.RecuperarContrasena)
                },
                onCreateAccount = {
                    navigate(RouteNavigation.CrearCuenta)
                }
            )
        }

        // ---------- RECUPERAR CONTRASEÑA ----------
        composable<RouteNavigation.RecuperarContrasena> {

            val recuperarViewModel: RecuperarContrasenaViewModel = viewModel(
                factory = RecuperarContrasenaViewModelFactory(application, authRepository)
            )

            RecuperarContrasenaPage(
                recuperarContrasenaViewModel = recuperarViewModel,
                onVolverLogin = ::volverALogin,
                onSolicitudEnviada = { email ->
                    navController.navigate(RouteNavigation.RestablecerContrasena(email)) {
                        popUpTo<RouteNavigation.RecuperarContrasena> {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        // ---------- RESTABLECER CONTRASEÑA ----------
        composable<RouteNavigation.RestablecerContrasena> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.RestablecerContrasena>()
            val restablecerViewModel: RestablecerContrasenaViewModel = viewModel(
                factory = RestablecerContrasenaViewModelFactory(
                    application = application,
                    email = route.email,
                    authRepository = authRepository
                )
            )
            RestablecerContrasenaPage(
                viewModel = restablecerViewModel,
                onVolverLogin = ::volverALogin
            )
        }

        // ---------- CREAR CUENTA ----------
        composable<RouteNavigation.CrearCuenta> {

            val crearCuentaViewModel: CrearCuentaViewModel = viewModel(
                factory = CrearCuentaViewModelFactory(application, authRepository)
            )

            CrearCuentaPage(
                crearCuentaViewModel = crearCuentaViewModel,
                onVolverLogin = ::volverALogin,
                onCuentaCreada = ::volverALogin
            )
        }

        // ---------- HOME EMPLEADO ----------
        composable<RouteNavigation.HomeEmpleado> { backStackEntry ->

            val route = backStackEntry.toRoute<RouteNavigation.HomeEmpleado>()

            val homeEmpleadoViewModel: HomeEmpleadoViewModel = viewModel(
                factory = HomeEmpleadoViewModelFactory(
                    application = application,
                    userId = route.userId,
                    incidenciasRepository = incidenciasRepository
                )
            )

            HomeEmpleadoPage(
                homeEmpleadoViewModel = homeEmpleadoViewModel,
                selectedTab = HomeTab.INICIO,
                onInicio = {},
                onNueva = {
                    navigate(RouteNavigation.NuevaIncidencia(route.userId))
                },
                onPerfil = {
                    navigate(RouteNavigation.Perfil(route.userId))
                },
                onIncidenciaClick = { incidencia ->
                    navigate(
                        RouteNavigation.DetalleIncidenciaEmpleado(
                            userId = route.userId,
                            incidenciaId = incidencia.id
                        )
                    )
                }
            )
        }

        // ---------- DETALLE DE INCIDENCIA DEL EMPLEADO ----------
        composable<RouteNavigation.DetalleIncidenciaEmpleado> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.DetalleIncidenciaEmpleado>()
            val detalleViewModel: DetalleIncidenciaEmpleadoViewModel = viewModel(
                factory = DetalleIncidenciaEmpleadoViewModelFactory(
                    application = application,
                    userId = route.userId,
                    incidenciaId = route.incidenciaId,
                    incidenciasRepository = incidenciasRepository
                )
            )

            DetalleIncidenciaEmpleadoPage(
                viewModel = detalleViewModel,
                onVolver = { navController.popBackStack() },
                onInicio = {
                    navigate(RouteNavigation.HomeEmpleado(route.userId))
                },
                onNueva = {
                    navigate(RouteNavigation.NuevaIncidencia(route.userId))
                },
                onPerfil = {
                    navigate(RouteNavigation.Perfil(route.userId))
                }
            )
        }

        // ---------- HOME TÉCNICO ----------
        composable<RouteNavigation.HomeTecnico> { backStackEntry ->

            val route = backStackEntry.toRoute<RouteNavigation.HomeTecnico>()
            val homeTecnicoViewModel: HomeTecnicoViewModel = viewModel(
                factory = HomeTecnicoViewModelFactory(
                    application = application,
                    userId = route.userId,
                    incidenciasRepository = incidenciasRepository
                )
            )

            HomeTecnicoPage(
                homeTecnicoViewModel = homeTecnicoViewModel,
                onIncidenciaClick = { incidencia ->
                    navigate(
                        RouteNavigation.DetalleIncidenciaTecnico(
                            userId = route.userId,
                            incidenciaId = incidencia.id,
                            titulo = incidencia.titulo,
                            categoria = incidencia.categoria,
                            prioridad = incidencia.prioridad,
                            fecha = incidencia.fecha,
                            estado = incidencia.estado,
                            desdeHomeTecnico = true
                        )
                    )
                },
                onPerfil = {
                    navigate(RouteNavigation.Perfil(route.userId, esTecnico = true))
                }
            )
        }

        // ---------- PANEL ADMINISTRADOR ----------
        composable<RouteNavigation.HomeAdmin> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.HomeAdmin>()
            val homeAdminViewModel: HomeAdminViewModel = viewModel(
                factory = HomeAdminViewModelFactory(
                    application,
                    route.userId,
                    administracionRepository
                )
            )

            HomeAdminPage(
                homeAdminViewModel = homeAdminViewModel,
                onIncidencias = {
                    navigate(RouteNavigation.AdminIncidencias(route.userId))
                },
                onUsuarios = {
                    navigate(RouteNavigation.AdminUsuarios(route.userId))
                },
                onPerfil = {
                    navigate(RouteNavigation.Perfil(route.userId, esAdmin = true))
                }
            )
        }

        // ---------- INCIDENCIAS DE ADMINISTRACIÓN ----------
        composable<RouteNavigation.AdminIncidencias> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.AdminIncidencias>()
            val homeTecnicoViewModel: HomeTecnicoViewModel = viewModel(
                factory = HomeTecnicoViewModelFactory(
                    application,
                    route.userId,
                    incidenciasRepository
                )
            )

            HomeTecnicoPage(
                homeTecnicoViewModel = homeTecnicoViewModel,
                onIncidenciaClick = { incidencia ->
                    navigate(
                        RouteNavigation.DetalleIncidenciaTecnico(
                            userId = route.userId,
                            incidenciaId = incidencia.id,
                            titulo = incidencia.titulo,
                            categoria = incidencia.categoria,
                            prioridad = incidencia.prioridad,
                            fecha = incidencia.fecha,
                            estado = incidencia.estado,
                            desdeHomeAdmin = true
                        )
                    )
                },
                onPerfil = {
                    navigate(RouteNavigation.Perfil(route.userId, esAdmin = true))
                },
                modoAdmin = true,
                onPanel = { navigate(RouteNavigation.HomeAdmin(route.userId)) },
                onUsuarios = { navigate(RouteNavigation.AdminUsuarios(route.userId)) },
                tituloPersonalizado = application.getString(R.string.incidents)
            )
        }

        // ---------- USUARIOS DE ADMINISTRACIÓN ----------
        composable<RouteNavigation.AdminUsuarios> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.AdminUsuarios>()
            val adminHomeEntry = remember(backStackEntry) {
                navController.getBackStackEntry<RouteNavigation.HomeAdmin>()
            }
            val adminUsuariosViewModel: AdminUsuariosViewModel = viewModel(
                viewModelStoreOwner = adminHomeEntry,
                factory = AdminUsuariosViewModelFactory(application, administracionRepository)
            )

            AdminUsuariosPage(
                adminUsuariosViewModel = adminUsuariosViewModel,
                onVolver = { navController.popBackStack() },
                onNuevoUsuario = {
                    navigate(RouteNavigation.AdminUsuario(route.userId))
                },
                onEditarUsuario = { usuario ->
                    navigate(RouteNavigation.AdminUsuario(route.userId, usuario.id))
                }
            )
        }

        composable<RouteNavigation.AdminUsuario> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.AdminUsuario>()
            val adminHomeEntry = remember(backStackEntry) {
                navController.getBackStackEntry<RouteNavigation.HomeAdmin>()
            }
            val adminUsuariosViewModel: AdminUsuariosViewModel = viewModel(
                viewModelStoreOwner = adminHomeEntry,
                factory = AdminUsuariosViewModelFactory(application, administracionRepository)
            )

            AdminCrearUsuarioCrearPage(
                usuario = route.usuarioId?.let { usuarioId ->
                    adminUsuariosViewModel.uiState.value.usuarios
                        .firstOrNull { it.id == usuarioId }
                },
                idNuevoUsuario = adminUsuariosViewModel.siguienteId(),
                onVolver = { navController.popBackStack() },
                onGuardar = { usuario, password, onGuardado ->
                    adminUsuariosViewModel.guardarUsuario(usuario, password, onGuardado)
                }
            )
        }

        // ---------- DETALLE DE INCIDENCIA ----------
        composable<RouteNavigation.DetalleIncidenciaTecnico> { backStackEntry ->

            val route = backStackEntry.toRoute<RouteNavigation.DetalleIncidenciaTecnico>()
            val incidentListOwner = remember(backStackEntry) {
                when {
                    route.desdeHomeAdmin ->
                        navController.getBackStackEntry<RouteNavigation.AdminIncidencias>()
                    else -> navController.getBackStackEntry<RouteNavigation.HomeTecnico>()
                }
            }
            val technicianHomeViewModel = viewModel<HomeTecnicoViewModel>(
                viewModelStoreOwner = incidentListOwner,
                factory = HomeTecnicoViewModelFactory(
                    application,
                    route.userId,
                    incidenciasRepository
                )
            )
            val refreshIncidentList = {
                technicianHomeViewModel.cargarIncidencias()
            }
            val detalleViewModel: DetalleEmpleadoViewModel = viewModel(
                factory = DetalleEmpleadoViewModelFactory(
                    application = application,
                    userId = route.userId,
                    incidenciaId = route.incidenciaId,
                    incidenciasRepository = incidenciasRepository
                )
            )

            DetalleIncideciaTecnicoPage(
                detalleEmpleadoViewModel = detalleViewModel,
                onVolver = {
                    refreshIncidentList()
                    navController.popBackStack()
                },
                onIncidencias = {
                    refreshIncidentList()
                    if (route.desdeHomeAdmin) {
                        navigate(RouteNavigation.AdminIncidencias(route.userId))
                    } else {
                        navigate(RouteNavigation.HomeTecnico(route.userId))
                    }
                },
                onPerfil = {
                    navigate(
                        RouteNavigation.Perfil(
                            route.userId,
                            esTecnico = !route.desdeHomeAdmin,
                            esAdmin = route.desdeHomeAdmin
                        )
                    )
                }
            )
        }

        // ---------- NUEVA INCIDENCIA ----------
        composable<RouteNavigation.NuevaIncidencia> { backStackEntry ->

            val route = backStackEntry.toRoute<RouteNavigation.NuevaIncidencia>()
            val homeEmpleadoEntry = remember(backStackEntry) {
                navController.getBackStackEntry<RouteNavigation.HomeEmpleado>()
            }
            val homeEmpleadoViewModel: HomeEmpleadoViewModel = viewModel(
                viewModelStoreOwner = homeEmpleadoEntry,
                factory = HomeEmpleadoViewModelFactory(
                    application,
                    route.userId,
                    incidenciasRepository
                )
            )

            val nuevaIncidenciaViewModel: NuevaIncidenciaViewModel = viewModel(
                factory = NuevaIncidenciaViewModelFactory(
                    application = application,
                    userId = route.userId,
                    incidenciasRepository = incidenciasRepository
                )
            )

            NuevaIncidenciaPage(
                nuevaIncidenciaViewModel = nuevaIncidenciaViewModel,
                onVolver = {
                    navController.popBackStack()
                },
                onIncidenciaCreada = {
                    homeEmpleadoViewModel.cargarIncidencias()
                    navController.popBackStack()
                }
            )
        }

        // ---------- PERFIL ----------
        composable<RouteNavigation.Perfil> { backStackEntry ->

            val route = backStackEntry.toRoute<RouteNavigation.Perfil>()
            val perfilOwner = remember(backStackEntry) {
                when {
                    route.esAdmin -> navController.getBackStackEntry<RouteNavigation.HomeAdmin>()
                    route.esTecnico -> navController.getBackStackEntry<RouteNavigation.HomeTecnico>()
                    else -> navController.getBackStackEntry<RouteNavigation.HomeEmpleado>()
                }
            }

            val perfilViewModel: PerfilViewModel = viewModel(
                viewModelStoreOwner = perfilOwner,
                factory = PerfilViewModelFactory(
                    application = application,
                    userId = route.userId,
                    perfilRepository = perfilRepository
                )
            )

            PerfilPage(
                perfilViewModel = perfilViewModel,
                modoTecnico = route.esTecnico,
                modoAdmin = route.esAdmin,
                onVolver = {
                    if (!navController.popBackStack()) {
                        if (route.esAdmin) {
                            navigate(RouteNavigation.HomeAdmin(route.userId))
                        } else if (route.esTecnico) {
                            navigate(RouteNavigation.HomeTecnico(route.userId))
                        } else {
                            navigate(RouteNavigation.HomeEmpleado(route.userId))
                        }
                    }
                },
                onInicio = {
                    if (route.esAdmin) {
                        navigate(RouteNavigation.HomeAdmin(route.userId))
                    } else if (route.esTecnico) {
                        navigate(RouteNavigation.HomeTecnico(route.userId))
                    } else {
                        navigate(RouteNavigation.HomeEmpleado(route.userId))
                    }
                },
                onNueva = {
                    if (route.esAdmin) {
                        navigate(RouteNavigation.AdminIncidencias(route.userId))
                    } else if (route.esTecnico) {
                        navigate(RouteNavigation.HomeTecnico(route.userId))
                    } else {
                        navigate(RouteNavigation.NuevaIncidencia(route.userId))
                    }
                },
                onUsuarios = {
                    if (route.esAdmin) {
                        navigate(RouteNavigation.AdminUsuarios(route.userId))
                    }
                },
                onEditarPerfil = { _ ->
                    navigate(
                        RouteNavigation.EditarPerfil(
                            userId = route.userId,
                            esTecnico = route.esTecnico,
                            esAdmin = route.esAdmin
                        )
                    )
                },
                onCerrarSesion = {
                    perfilViewModel.limpiarPerfil()
                    coroutineScope.launch {
                        application.cerrarSesion()
                        navController.navigate(RouteNavigation.Login) {
                            popUpTo(navController.graph.id) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // ---------- EDITAR PERFIL ----------
        composable<RouteNavigation.EditarPerfil> { backStackEntry ->
            val route = backStackEntry.toRoute<RouteNavigation.EditarPerfil>()
            val perfilOwner = remember(backStackEntry) {
                when {
                    route.esAdmin -> navController.getBackStackEntry<RouteNavigation.HomeAdmin>()
                    route.esTecnico -> navController.getBackStackEntry<RouteNavigation.HomeTecnico>()
                    else -> navController.getBackStackEntry<RouteNavigation.HomeEmpleado>()
                }
            }
            val perfilViewModel: PerfilViewModel = viewModel(
                viewModelStoreOwner = perfilOwner,
                factory = PerfilViewModelFactory(application, route.userId, perfilRepository)
            )
            val perfilState by perfilViewModel.uiState.collectAsState()
            LaunchedEffect(route.userId, perfilState.perfil) {
                if (perfilState.perfil == null && !perfilState.isLoading) {
                    perfilViewModel.cargarPerfil()
                }
            }
            val editarPerfilViewModel: EditarPerfilViewModel = viewModel(
                factory = EditarPerfilViewModelFactory(
                    application,
                    route.userId,
                    perfilRepository
                )
            )

            perfilState.perfil?.let { perfil ->
                EditarPerfilPage(
                    editarPerfilViewModel = editarPerfilViewModel,
                    perfil = perfil,
                    onVolver = { navController.popBackStack() },
                    onGuardar = { datos ->
                        perfilViewModel.actualizarPerfil(
                            perfil.copy(
                                nombre = datos.nombre,
                                apellidos = datos.apellidos,
                                email = datos.email,
                                telefono = datos.telefono
                            )
                        )
                        navController.popBackStack()
                    }
                )
            } ?: Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                if (perfilState.isLoading) {
                    CircularProgressIndicator()
                } else {
                    Text(
                        text = perfilState.errorMessage
                            ?: application.getString(R.string.error_load_profile)
                    )
                }
            }
        }
    }
}